import java.util.ArrayList;

/**
 * Enum type to list all airline names
 * @author Steven Gong
 * Assignment HW05
 * Email: stevengo@usc.edu
 */
public enum Airline {
	SOUTHWEST,
	UNITED,
	AMERICAN,
	JETBLUE,
	SPIRIT;
	
//	// constructor
//	private Airline() {
//		ArrayList<Airline>myAirline;
//		myAirline = new ArrayList<Airline>();
//	}
	
	// toString
	public String toString() {
		String s = super.toString();
		return s;
	}
	
}
